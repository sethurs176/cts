package com.cts;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;
import org.littleshoot.proxy.HttpProxyServer;
import org.littleshoot.proxy.HttpProxyServerBootstrap;
import org.littleshoot.proxy.impl.DefaultHttpProxyServer;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.core.har.HarPage;
import net.lightbody.bmp.mitm.CertificateAndKeySource;
import net.lightbody.bmp.mitm.RootCertificateGenerator;
import net.lightbody.bmp.mitm.TrustSource;
import net.lightbody.bmp.mitm.keys.ECKeyGenerator;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;

public abstract class SynmonWrapper {

	private String applicationName;
	private String connectionString;
	private String region;
	private String serverURLPrefix;
	private StopWatch pageLoad;

	/** For Browser mob proxy **/
	private BrowserMobProxy proxy;
	protected ChromeDriver driver;
	
	
	public void initialize(String applicationName, String region, String serverURLPrefix) {

		System.out.println("JRE : " + System.getProperty("java.home"));
		this.applicationName = applicationName;
		if (region != null && region.length() > 0)
			this.region = region;
		else
			this.region = "TEST";
		
		this.serverURLPrefix = serverURLPrefix;

		// create a RootCertificateGenerator that generates EC Certificate Authorities; you may also load your
	    // own EC certificate and private key using any other CertificateAndKeySource implementation 
	    // (KeyStoreFileCertificateSource, PemFileCertificateSource, etc.).
	    CertificateAndKeySource rootCertificateGenerator = RootCertificateGenerator.builder()
	            .keyGenerator(new ECKeyGenerator())
	            .build();

	    // tell the ImpersonatingMitmManager to generate EC keys and to use the EC RootCertificateGenerator
	    ImpersonatingMitmManager mitmManager = ImpersonatingMitmManager.builder()
	            .rootCertificateSource(rootCertificateGenerator)
	            .serverKeyGenerator(new ECKeyGenerator())
	            .build();
	            
		// Initialize proxy server (Browser mob proxy)
		// start the proxy
		proxy = new BrowserMobProxyServer();
		proxy.setMitmManager(mitmManager);
		//proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
		proxy.setTrustAllServers(true);
		proxy.start();
		Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
		try {
			String hostIp = Inet4Address.getLocalHost().getHostAddress();
			seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
			seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		
		//String chromeDriverLocation = "C:\\SynMon\\Chromedriver\\chromedriver.exe";
		// String userDataProfileLocation =
		// "C:\\Users\\Administrator\\AppData\\Local\\Google\\Chrome\\User Data";
		//String userDataProfileLocation = "C:\\Users\\121009\\AppData\\Local\\Google\\Chrome\\User Data";
		//String userDataProfileLocation = "%LOCALAPPDATA%\\Google\\Chrome\\User Data";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

		System.out.println("----------- " + sdf.format(new Date())+" :  STARTING MEASUREMENTS ---------- ");
		System.out.println("Region : " + region);
		//System.out.println("Chrome Driver location : " + chromeDriverLocation);
		//System.out.println("User data location : " + userDataProfileLocation);
		//System.out.println("----------------------------------------- ");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		capabilities.setCapability (CapabilityType.SUPPORTS_APPLICATION_CACHE, true);
		
		ChromeDriverService service = new ChromeDriverService.Builder()
				//.usingDriverExecutable(new File(chromeDriverLocation))
				.usingAnyFreePort().build();
		ChromeOptions options = new ChromeOptions();
		/*if(userDataProfileLocation!=null && !userDataProfileLocation.equals(""))
			options.addArguments("user-data-dir="+userDataProfileLocation);*/
		options.merge(capabilities);
		
		driver = new ChromeDriver(service, options);
		driver.manage().window().maximize();
		
		System.out.println("Webdriver initialized");

	}
	
	public BrowserMobProxy getProxy() {
		return proxy;
	}
	
	//The user has to implement only this method 
	public abstract void executeScript();


	public void startTransaction(String transactionName) {
		pageLoad = new StopWatch();
		//System.out.println("Tx " + transactionName+" start1 : " + (new Date().getTime()));
		pageLoad.start();
		//System.out.println("Tx " + transactionName+" start2 : " + (new Date().getTime()));

	}
	
	public void startTransactionEx(String transactionName) {
		// create a new HAR with the label "yahoo.com"
	    proxy.newHar(transactionName);
	    startTransaction(transactionName);
	}

	public void endTransaction(String transactionName, String status, ChromeDriver driver) {
		long pageLoadTime_ms=0;
		//System.out.println("Tx " + transactionName+" end1 : " + (new Date().getTime()));
		if(pageLoad!=null && pageLoad.isStarted()) {
			pageLoad.stop();
			pageLoadTime_ms = pageLoad.getTime();
		}
			
		//System.out.println("Tx " + transactionName+" end2 : " + (new Date().getTime()));
		
		String jsEvents = null;
		if(driver!=null) {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			jsEvents = getPageStats(js);	
		}
		
		
		
		// (new MyInfluxDBClient(dbHost, dbPort)).insertDataToInfluxDB(transactionName,
		// status, region, applicationName, pageLoadTime_Seconds);
		/*(new MyElasticSearchClient(dbHost, dbPort)).insertToElasticSearch(transactionName, status, region,
				applicationName, pageLoadTime_ms, null, jsEvents);
		(new MyInfluxDBClient(dbHost, 8086, applicationName)).insertDataToInfluxDB(transactionName,
				status, region, pageLoadTime_ms);*/
				
	}
	
	public void endTransactionEx(String transactionName, String status, long sla, ChromeDriver driver) {
		long pageLoadTime_ms = 0;
		try {
			if(pageLoad!=null && pageLoad.isStarted()) {
				pageLoad.stop();
				pageLoadTime_ms = pageLoad.getTime();
			}
				
		}catch(Exception Ex) {
			Ex.printStackTrace();
			return;
		}
		
		
	
		System.out.println("********* Transaction name : " + transactionName+", E2EResponsetime : " + pageLoadTime_ms);
		Har har=null;
		
		//Only if response time > SLA, save the HAR file entries in DB
		
		if(pageLoadTime_ms>sla) {
			if(proxy!=null) {
				if(proxy.getHar()!=null) {
					har = proxy.getHar();
					System.out.println("# of HAR file entries : " + har.getLog().getEntries().size());
				}else {
					System.err.println("HAR file is null for : " + transactionName);
				}
			}else {
				System.err.println("Proxy is null : " + transactionName);
			}
		}

		String jsEvents = null;
		if(driver!=null) {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			try{
				jsEvents = getPageStats(js);	
			}catch(Exception ex) {
				jsEvents= "";
			}
		}
		
        int totalRequestCount=0;
        int passRequestCount=0;
        int failRequestCount=0;
        long totalTransactionSize=0;
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        String dateString = sdf.format(new Date());
        String screenshotPrefix = "default\\"+applicationName;
        String myJSON = "{" + 
                                        "    \"application\" : \""+applicationName+"\"," +
                                        "    \"transaction\" : \""+transactionName+"\"," +
                                        "    \"sampleSource\" : \"SeleniumScript\"," + 
                                        //"    \"screenshotPrefix\" : \""+ screenshotPrefix+"\"," +
                                        "              \"region\" : \""+region+"\"," +
                                        "              \"status\" : \""+status+"\"," + 
                                        "    \"responsetime\" : "+pageLoadTime_ms+"," + 
                                        jsEvents+","+
                                        "    \"post_date\" : \""+dateString+"\"";
        
        
        if(har!=null) {
                        myJSON = myJSON+",\"NetworkStatsCalls\" : true";
                        myJSON = myJSON+",    \"NetworkCalls\" : [";
                        List<HarPage> harPageList = har.getLog().getPages();
                        System.out.println("# of harPages : " + harPageList.size());
                        Iterator<HarPage> myIterator = harPageList.listIterator();
                        
                        List<HarEntry> entries = har.getLog().getEntries();
                        for(int i=0;i<entries.size();i++){
                                        HarEntry entry =entries.get(i);
                                        //System.out.println("\t"+entry.getRequest().getUrl()+",\tStatus: " + entry.getResponse().getStatus() +",\tTime: " + entry.getTime()+",\t Size: "+entry.getResponse().getBodySize());
                                        myJSON = myJSON+"{";
                                        myJSON = myJSON+"\"url\":\""+entry.getRequest().getUrl()+"\",";
                                        myJSON = myJSON+"\"status\":"+entry.getResponse().getStatus()+",";
                                        myJSON = myJSON+"\"statustext\":\""+entry.getResponse().getStatusText()+"\",";
                                        myJSON = myJSON+"\"method\":\""+entry.getRequest().getMethod()+"\",";
                                        myJSON = myJSON+"\"mimetype\":\""+entry.getResponse().getContent().getMimeType()+"\",";
                                        long loadTime = entry.getTime();
                                        if(loadTime<0)
                                                        loadTime=0;
                                        
                                        myJSON = myJSON+"\"loadtime\":"+loadTime+",";
                                        myJSON = myJSON+"\"blockedTime\":"+entry.getTimings().getBlocked()+",";
                                        myJSON = myJSON+"\"connectTime\":"+entry.getTimings().getConnect()+",";
                                        myJSON = myJSON+"\"dnsTime\":"+entry.getTimings().getDns()+",";
                                        myJSON = myJSON+"\"receiveTime\":"+entry.getTimings().getReceive()+",";
                                        myJSON = myJSON+"\"sendTime\":"+entry.getTimings().getSend()+",";
                                        myJSON = myJSON+"\"sslTime\":"+entry.getTimings().getSsl()+",";
                                        myJSON = myJSON+"\"waitTime\":"+entry.getTimings().getWait()+",";
                                        
                                        String startTimeString = sdf.format(entry.getStartedDateTime());
                                        myJSON = myJSON+"\"starttime\":\""+startTimeString+"\",";
                                        long responseSize = entry.getResponse().getBodySize() + entry.getRequest().getHeadersSize();
                                        if(responseSize<0)
                                                        responseSize=0;
                                        myJSON = myJSON+"\"responsesize\":"+responseSize;
                                        
                                        myJSON = myJSON+"}";
                                        if(i<entries.size()-1)
                                                        myJSON = myJSON+",";
                                        
                                        totalRequestCount++;
                                        totalTransactionSize=totalTransactionSize + responseSize;
                                        
                        }
                        myJSON = myJSON+"]";
        }else {
                        myJSON = myJSON+",\"NetworkStatsCalls\" : false";
        }
        myJSON = myJSON+",\"TotalRequestsCount\" : "+totalRequestCount+"";
        myJSON = myJSON+",\"TotalTransactionSize\" : "+totalTransactionSize+"";
                        myJSON = myJSON+       "}";
        
                        //String myURL = this.serverURLPrefix+"/samplesAPI/insertNewSample";
                        String myURL = this.serverURLPrefix+"/seleniumAPI/insertNewSample";
                        //System.out.println("Before HTTP POST TO : " + myURL);
                        //Do HTTP post with this JSON to server
                        CloseableHttpClient  httpClient = HttpClientBuilder.create().build();
                        String jsonResponse = "";
                        try {

                            HttpPost request = new HttpPost(myURL);
                            StringEntity params = new StringEntity(myJSON.toString());
                            request.addHeader("content-type", "application/json");
                            request.setEntity(params);
                            HttpResponse httpResponse = httpClient.execute(request);
                            
                            System.out.println("---- Response after POST : " + httpResponse.toString());
                			// handle response here...

                			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

                			String inputLine;
                			StringBuffer responseText = new StringBuffer();

                			while ((inputLine = reader.readLine()) != null) {
                				responseText.append(inputLine);
                			}
                			reader.close();

                			System.out.println("----- Response from Node : "+responseText.toString());
                			jsonResponse = responseText.toString();

                            //System.out.println("Response after POST : " + response.toString());
                            //handle response here...
                            
                        }catch (Exception ex) {
                                        ex.printStackTrace();

                        } finally {
                                        try {
                                                        httpClient.close();
                                        } catch (IOException e) {
                                                        e.printStackTrace();
                                        }
                        }
                        
                        //Now take screenshot and post it
                        if(jsonResponse!=null && !jsonResponse.equals("")) {
                        	System.out.println("Taking screenshot..");
                        	System.out.println("jsonResponse : " + jsonResponse);
                            File screenshotFile = null;
                            BufferedReader reader=null;
                            CloseableHttpResponse httpResponse = null;
                            CloseableHttpClient httpclient = null;
                            try {
                            	screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                    			JSONObject esResponseObject  = new JSONObject(jsonResponse);
                    			System.out.println("JSON response : " + jsonResponse);
                    			String resID = esResponseObject.getString("_id");
                    			
                    			String urlString = this.serverURLPrefix + "/fileupload/uploadScreenshots";

                    			

                    			httpclient = HttpClients.custom().build();
                    			
                    			System.out.println("Before screenshot POST TO : " + urlString);
                    			HttpPost httpPost = new HttpPost(urlString);

                    			
                    			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
                    			builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
                    			System.out.println("Screenshot file : " + screenshotFile.getAbsolutePath() +", " + screenshotFile.getName());
                    			builder.addBinaryBody("photo", screenshotFile, ContentType.DEFAULT_BINARY, screenshotFile.getName());
                    			builder.addPart("applicationID", new StringBody(applicationName, ContentType.MULTIPART_FORM_DATA));
                    			//builder.addPart("customerID", new StringBody(customerID, ContentType.MULTIPART_FORM_DATA));
                    			builder.addPart("esResponseID", new StringBody(resID, ContentType.MULTIPART_FORM_DATA));
                    			HttpEntity entity = builder.build();
                    			
                    			httpPost.setEntity(entity);
                    			
                    			httpResponse = httpclient.execute(httpPost);

                    			reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

                    			String inputLine;
                    			StringBuffer response = new StringBuffer();

                    			while ((inputLine = reader.readLine()) != null) {
                    				response.append(inputLine);
                    			}
                    			
                    			

                    			System.out.println(response.toString());

                            }catch(Exception ex) {
                            	ex.printStackTrace();
                            }finally {
                            	if(reader!=null) {
									try {
										reader.close();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
                            	}
                            	
                            	if(httpclient!=null) {
                            		try {
										httpclient.close();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
                            	}
                            	
                            	if(httpResponse!=null) {
                            		try {
										httpResponse.close();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
                            	}
                            	
                            }
                        }
                        
                        

		
		
		/*(new MyElasticSearchClient(dbHost, dbPort)).insertToElasticSearch(transactionName, status, region,
				applicationName, pageLoadTime_ms, har, jsEvents);
		(new MyInfluxDBClient(dbHost, 8086, applicationName)).insertDataToInfluxDB(transactionName,
				status, region, pageLoadTime_ms);*/
		
		
	}
	
	/*public void endTransactionEx(String transactionName, String status, long sla, ChromeDriver driver, String description) {
		try {
			pageLoad.stop();
		}catch(Exception Ex) {
			Ex.printStackTrace();
			return;
		}
		
		long pageLoadTime_ms = pageLoad.getTime();
	
		System.out.println("********* Transaction name : " + transactionName+", E2EResponsetime : " + pageLoadTime_ms);
		Har har=null;
		
		//Only if response time > SLA, save the HAR file entries in DB
		
		if(pageLoadTime_ms>sla) {
			if(proxy!=null) {
				if(proxy.getHar()!=null) {
					har = proxy.getHar();
					System.out.println("# of HAR file entries : " + har.getLog().getEntries().size());
				}else {
					System.err.println("HAR file is null for : " + transactionName);
				}
			}else {
				System.err.println("Proxy is null : " + transactionName);
			}
		}

		String jsEvents = null;
		if(driver!=null) {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			try{
				jsEvents = getPageStats(js);	
			}catch(Exception ex) {
				jsEvents= "";
			}
		}
		
		
		
		(new MyElasticSearchClient(dbHost, dbPort)).insertToElasticSearch(transactionName, status, region,
				applicationName, pageLoadTime_ms, har, jsEvents);
		(new MyInfluxDBClient(dbHost, 8086, applicationName)).insertDataToInfluxDB(transactionName,
				status, region, pageLoadTime_ms);
		
		
	}*/
	
	
	private String getPageStats(JavascriptExecutor js) throws NoSuchSessionException{
		
		long loadEventEnd = (long) Double.valueOf(js.executeScript("return window.performance.timing.loadEventEnd;").toString()).doubleValue();
		long loadEventStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.loadEventStart;").toString()).doubleValue();
		long domComplete= (long) Double.valueOf(js.executeScript("return window.performance.timing.domComplete;").toString()).doubleValue();
		long domContentLoadedEventEnd= (long) Double.valueOf(js.executeScript("return window.performance.timing.domContentLoadedEventEnd;").toString()).doubleValue();
		long domContentLoadedEventStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.domContentLoadedEventStart;").toString()).doubleValue();
		long domInteractive= (long) Double.valueOf(js.executeScript("return window.performance.timing.domInteractive;").toString()).doubleValue();
		long domLoading= (long) Double.valueOf(js.executeScript("return window.performance.timing.domLoading;").toString()).doubleValue();
		long responseEnd= (long) Double.valueOf(js.executeScript("return window.performance.timing.responseEnd;").toString()).doubleValue();
		long responseStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.responseStart;").toString()).doubleValue();
		long connectEnd= (long) Double.valueOf(js.executeScript("return window.performance.timing.connectEnd;").toString()).doubleValue();
		long requestStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.requestStart;").toString()).doubleValue();
		long secureConnectionStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.secureConnectionStart;").toString()).doubleValue();
		long connectStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.connectStart;").toString()).doubleValue();
		long domainLookupEnd= (long) Double.valueOf(js.executeScript("return window.performance.timing.domainLookupEnd;").toString()).doubleValue();
		long domainLookupStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.domainLookupStart;").toString()).doubleValue();
		long fetchStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.fetchStart;").toString()).doubleValue();
		long navigationStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.navigationStart;").toString()).doubleValue();
		long redirectEnd= (long) Double.valueOf(js.executeScript("return window.performance.timing.redirectEnd;").toString()).doubleValue();
		long redirectStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.redirectStart;").toString()).doubleValue();
		long unloadEventEnd= (long) Double.valueOf(js.executeScript("return window.performance.timing.unloadEventEnd;").toString()).doubleValue();
		long unloadEventStart= (long) Double.valueOf(js.executeScript("return window.performance.timing.unloadEventStart;").toString()).doubleValue();

		
		long redirectionTime = redirectEnd - navigationStart;
		if(redirectionTime<0)
			redirectionTime=0;
		
		long totalLoadTime = loadEventEnd - fetchStart;
		if(totalLoadTime<0)
			totalLoadTime = 0;
		
		long totalDOMContentLoadTime = domContentLoadedEventEnd - fetchStart;
		if(totalDOMContentLoadTime<0)
			totalDOMContentLoadTime=0;
		
		long timeToFirstByte = responseStart - requestStart;
		if(timeToFirstByte<0)
			timeToFirstByte=0;
		
		System.out.println("LoadTime: " + totalLoadTime+", DOMContentLoadTime: " + totalDOMContentLoadTime + ", RedirectionTime: " +redirectionTime+", TTFB: " + timeToFirstByte );
		String pageStatsJSON =
				"\"LoadTime\" : "+totalLoadTime+","+
				"\"DOMContentLoadTime\" : "+totalDOMContentLoadTime+","+
				"\"RedirectionTime\" : "+redirectionTime+","+
				"\"TimeToFirstByte\" : "+timeToFirstByte+","+
				" \"pageStats\" : "+
				"{"+
				"    \"loadEventEnd\" : "+loadEventEnd+"," +
				"    \"loadEventStart\" : "+loadEventStart+"," +
				"    \"domComplete\" : "+domComplete+"," +
				"    \"domContentLoadedEventEnd\" : "+domContentLoadedEventEnd+"," +
				"    \"domContentLoadedEventStart\" : "+domContentLoadedEventStart+"," +
				"    \"domInteractive\" : "+domInteractive+"," +
				"    \"domLoading\" : "+domLoading+"," +
				"    \"responseEnd\" : "+responseEnd+"," +
				"    \"responseStart\" : "+responseStart+"," +
				"    \"connectEnd\" : "+connectEnd+"," +
				"    \"requestStart\" : "+requestStart+"," +
				"    \"secureConnectionStart\" : "+secureConnectionStart+"," +
				"    \"connectStart\" : "+connectStart+"," +
				"    \"domainLookupEnd\" : "+domainLookupEnd+"," +
				"    \"domainLookupStart\" : "+domainLookupStart+"," +
				"    \"fetchStart\" : "+fetchStart+"," +
				"    \"navigationStart\" : "+navigationStart+"," +
				"    \"redirectEnd\" : "+redirectEnd+"," +
				"    \"redirectStart\" : "+redirectStart+"," +
				"    \"unloadEventEnd\" : "+unloadEventEnd+"," +
				"    \"unloadEventStart\" : "+unloadEventStart+
				"}";
		
		//System.out.println(pageStatsJSON);
		return pageStatsJSON;
	}
	
	

	public void pause(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public void close() {
		// Close Chrome
				driver.close();
				driver.quit();
				proxy.stop();
				System.out.println("-- End of measurements --");
				System.exit(0);
	}
	
	public static void main(String s[]) {
		System.out.println("SynmonWrapper!");
	}

}
