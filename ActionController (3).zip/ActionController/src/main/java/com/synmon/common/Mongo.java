package com.synmon.common;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Filters;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Projections.*;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.result.UpdateResult;
import com.synmon.common.Mongo;

import java.util.Arrays;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.json.simple.*;

import java.util.Arrays;

public class Mongo {
	/*private static MongoClient mongoClient;
	private	static MongoDatabase database;
	private	static MongoCollection<Document> collection;
	private	static String DbName="scheduling_database";
	private static String collectionName="scheduling_table";
	
	public static MongoClient getMongoConnection() {
		System.out.println("Creating MongoDB Connection");
		MongoClient mc=null;
		try {
			mc = new MongoClient();
			System.out.println("Created MongoDB Connection");
		}catch(Exception ex) {
			System.out.println(ex);
		}
		return mc;
	}
	
	public static MongoDatabase getDatabase(MongoClient client, String Dbname){
		System.out.println("Getting database: " + Dbname);
		MongoDatabase md=null;
		try {
			md = client.getDatabase(Dbname);
		}catch(Exception ex) {
			System.out.println(ex);
		}
		return md;
	}
	
	public static MongoCollection<Document> getCollection(MongoDatabase database, String collectionName){ 
		System.out.println("Getting Collection: " + collectionName);
		MongoCollection<Document> mcoll=null;
		try {
			mcoll = database.getCollection(collectionName);
		}catch(Exception ex) {
			System.out.println(ex);
		}
		return mcoll;
	}
	
	public static Block<Document> printBlock = new Block<Document>() {
	       @Override
	       public void apply(final Document document) {
	           System.out.println(document.toJson());
	           System.out.println(document.getString("appid"));
	           System.out.println(document.getString("scriptname"));
	           System.out.println(document.getString("file_location"));
	           System.out.println(document.getString("regions"));
	           System.out.println(document.getString("monitoring_interval"));
	       }
	};
	
	
	public static void main(String args[]) {
		try {
			System.out.println("Application Started !");
			mongoClient = getMongoConnection();
			
			DbName = "scheduling_database";
			collectionName =  "scheduling_table";
			database = getDatabase(mongoClient, DbName);
			collection = getCollection(database, collectionName);
			
			
			updateStatusMongoDoc("5ba4bbdf08b7f90be494eaba","stopped123");
			mongoClient.close();
		}catch(Exception ex) {
			System.out.println(ex);
		}
	}

	
	public static void updateStatusMongoDoc(String DocId,String status) {
		try {
			Mongo mdb = new Mongo();
			System.out.println("updateStatusMongoDoc Started ");
			mongoClient = mdb.getMongoConnection();
			
			database = mdb.getDatabase(mongoClient, DbName);
			collection = mdb.getCollection(database, collectionName);
			
			Bson filter = new BasicDBObject("_id", new ObjectId(DocId));
			Bson newValue = new Document("status", status);
			Bson updateOperationDocument = new Document("$set", newValue);
			UpdateResult UR = collection.updateOne(filter, updateOperationDocument);
			
			mongoClient.close();
		}catch(Exception ex) {
			System.out.println(ex);
		}
	}
	
	public static String getDocumentById(MongoCollection<Document> collection, String Id) {
		Bson query = new BasicDBObject("_id", new ObjectId(Id));
		Document doc =collection.find(query).first();
		return doc.toJson();
	}
	
	
	public Mongo(){
		
	}*/
}
