package com.synmon.common;

import java.util.HashMap;
import java.util.Timer;

public class CommonData {
	public static HashMap<String, Timer> timerTasksMap;
	
	
	
	
}
