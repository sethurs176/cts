package com.synmon.common;



import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;
import java.util.Timer;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
 

 
@SuppressWarnings("serial")
public class StartupServlet extends HttpServlet
{
 
    public void init() throws ServletException
    {
          System.out.println("----------");
      	CommonData.timerTasksMap = new HashMap<String, Timer>();
		System.out.println("------Initialized the HashMap----");
    }
}