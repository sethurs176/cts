package com.synmon.db;
import com.mongodb.*;
import com.mongodb.MongoClient;
import com.mongodb.client.*;
import com.mongodb.client.result.UpdateResult;
import com.synmon.common.CommonData;

import java.io.FileInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

public class MongoDAO {

	private	 String DbName;//="scheduling_database";
	private  String collectionName;//="scheduling_table";
	private  String customersCollectionName;//="Customers";
	private  String DbHostName;
	private String mongoDBUrl;
//	private	 String DbName="scheduling_database";
//	private  String collectionName="scheduling_table";
//	private  String customersCollectionName="Customers";
	public MongoDAO()
	{
		Properties prop = new Properties();
		InputStream input = null;
		try {
//			input = new FileInputStream("config.properties");
			input=getClass().getResourceAsStream("/config.properties"); 
			// load a properties file
			prop.load(input);
			this.DbName=prop.getProperty("DbName");
			this.collectionName=prop.getProperty("collectionName");
			this.customersCollectionName=prop.getProperty("DbName");
			this.DbHostName=prop.getProperty("DbHostName");
			this.mongoDBUrl=prop.getProperty("mongoDBURL");
			
		}catch (IOException ex) {
			ex.printStackTrace();
		}
		finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public String getDocumentByID(String id) {
		
		MongoClient mc=null;
		MongoDatabase md=null;
		MongoCollection<Document> mcoll=null;
		String jsonResponse="{}";
		try {
//			MongoClientURI uri = new MongoClientURI("mongodb://synmon:synmon2020@ec2-13-126-49-100.ap-south-1.compute.amazonaws.com/?authSource=SynMonDB&authMechanism=SCRAM-SHA-1");
			MongoClientURI uri = new MongoClientURI(this.mongoDBUrl);
			mc = new MongoClient(uri);
/*			char[] pass ={ 's', 'y', 'n', 'm', 'o', 'n', '2', 'o', '2', 'o' }; 
			MongoCredential credential = MongoCredential.createScramSha1Credential("synmon", "SynMonDB", pass);
			mc = new MongoClient(new ServerAddress("localhost", 27017), Arrays.asList(credential));*/
//			mc = new MongoClient(DbHostName);
			md = mc.getDatabase(DbName);
			mcoll = md.getCollection(collectionName);
			Bson query = new BasicDBObject("_id", new ObjectId(id));
			Document doc =mcoll.find(query).first();
			if(doc==null) {
				System.err.println("Document search with ID failed with null returned value : " + id);
			}else {
				jsonResponse=doc.toJson();
			}
			
		}catch(Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();
		}finally {
			mc.close();
		}
		return jsonResponse;
	}
	
	public void updateRunStatus(String id, String status) {
		
		MongoClient mc=null;
		MongoDatabase md=null;
		MongoCollection<Document> mcoll=null;
		try {
//			MongoClientURI uri = new MongoClientURI("mongodb://synmon:synmon2020@ec2-13-126-65-4.ap-south-1.compute.amazonaws.com/?authSource=SynMonDB&authMechanism=SCRAM-SHA-1");
			MongoClientURI uri = new MongoClientURI(this.mongoDBUrl);
			mc = new MongoClient(uri);

			/*char[] pass ={ 's', 'y', 'n', 'm', 'o', 'n', '2', 'o', '2', 'o' }; 
			MongoCredential credential = MongoCredential.createScramSha1Credential("synmon", "SynMonDB", pass);
			mc = new MongoClient(new ServerAddress("localhost", 27017), Arrays.asList(credential));*/
//			mc = new MongoClient(DbHostName);
			md = mc.getDatabase(DbName);
			mcoll = md.getCollection(collectionName);
			Bson filter = new BasicDBObject("_id", new ObjectId(id));
			
			Bson newValue = new Document("status", status);
			Bson updateOperationDocument = new Document("$set", newValue);
			UpdateResult UR = mcoll.updateOne(filter, updateOperationDocument);
			
/*{ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, 
			{ $set: { "application.$[a].scripts.$[s].regions": regions, "application.$[a].scripts.$[s].monitoring_interval": interval } },
			{ arrayFilters: [{ "a.appid": mongo.ObjectId(applicationId) }, { "s.scriptid": mongo.ObjectId(scriptId) }] }
			*/
			/*
			 * mcoll = md.getCollection(customersCollectionName); filter = new
			 * BasicDBObject("_id", new ObjectId(id)); newValue = new Document("status",
			 * status).; updateOperationDocument = new Document("$set", newValue); UR =
			 * mcoll.updateOne(filter, updateOperationDocument);
			 */
			
			
			
		}catch(Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();
		}finally {
			mc.close();
		}
	}
}
