package com.synmon.rest;
 
import java.io.IOException;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;
import com.synmon.common.CommonData;
import com.synmon.db.MongoDAO;
  
@Path("/stopscript")
public class StopScriptService {
  
	private String queueSuffixString = "CIEEM_task_queue";
	
    @GET
    @Path("/{id}")
    public Response getMsg(@PathParam("id") String id) {
    	int statusCode=200;
        String output = "To stop script with id   : " + id;
  
        MongoDAO myDAO = new MongoDAO();
        //Get updated mondodb document
        String documentString = myDAO.getDocumentByID(id);
        JSONParser jsonparser=new JSONParser();
        JSONObject doc=null;
        try {
			doc = (JSONObject) jsonparser.parse(documentString);
		} catch (ParseException e) {
			e.printStackTrace();
			statusCode=500;
			output=e.getMessage();
		}
        
        //Check hashmap if this already exists
        if((CommonData.timerTasksMap.containsKey(doc.get("_id").toString()))&&(doc.get("status").toString()!="disabled")) {
			String mongoid = doc.get("_id").toString();
			Timer ctimer = CommonData.timerTasksMap.get(mongoid);
			ctimer.cancel();

			System.out.println("stopTimer: "+id);
			CommonData.timerTasksMap.remove(mongoid);
			System.out.println(doc.get("_id").toString()+" Timer Stopped");
			output = "Script scheduling stopped";
		}else {
			System.out.println(id+ " not in hashtable or status is disabled");
			output = "Script reference not found - It is already stopped or deleted";
		}		
        //Update Document status to "Stopped" in MongoDB

        myDAO.updateRunStatus(id, "Stopped");

        
        return Response.status(statusCode).entity(output).build();
  
    }
    
  
}