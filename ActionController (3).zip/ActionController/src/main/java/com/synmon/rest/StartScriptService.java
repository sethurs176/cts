
package com.synmon.rest;
 
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mongodb.util.JSON;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;
import com.synmon.common.CommonData;
import com.synmon.db.MongoDAO;
  
@Path("/startscript")
public class StartScriptService {
  
	private String queueSuffixString = "CIEEM_task_queue";
	
    @GET
    @Path("/{id}")
    public Response getMsg(@PathParam("id") String id) {
    	int statusCode=200;
        String output = "To start script with id   : " + id;
  
        //Update Document status to "Runnable" in MongoDB
        MongoDAO myDAO = new MongoDAO();
        myDAO.updateRunStatus(id, "Runnable");
        
        //Get updated mondodb document
        String documentString = myDAO.getDocumentByID(id);
        JSONParser jsonparser=new JSONParser();
        JSONObject doc=null;
        try {
        	System.out.println(documentString);
			doc = (JSONObject) jsonparser.parse(documentString);
		} catch (ParseException e) {
			e.printStackTrace();
			statusCode=500;
			output=e.getMessage();
		}
        
        if(CommonData.timerTasksMap==null) {
        	CommonData.timerTasksMap = new HashMap<String, Timer>();
        }
        
        //Check hashmap if this already exists
		if((!CommonData.timerTasksMap.containsKey(doc.get("_id").toString()))&&(doc.get("status").toString()!="disabled")) {
			//If not exists in Hashmap, create timer
			//Add it to Hashmap
			Timer returnedTime = createTimerTask(id,doc);
			if(returnedTime ==null) {
				System.out.println("Returned timer is null");
			}
			CommonData.timerTasksMap.put(doc.get("_id").toString(), returnedTime);
			output="Script schedule started";
		}else {
			//If exists, return a message saying it is already in runnable state
			System.out.println(id+ " already exists in hashtable or status is disabled");
			output="Script is already in runnable state or deleted";
		}
        return Response.status(statusCode).entity(output).build();
  
    }
    
	private Timer createTimerTask(final String docid, final JSONObject document) {

		Timer timer = null;
			//String[] regions = document.get("regions").toString().split(",");
			//JSONArray regionsJSONArray = (JSONArray)document.get("regions");
			String jsonString = document.get("regions").toString();
			jsonString = jsonString.replace("[", "");
			jsonString = jsonString.replace("]", "");
			final String[] regions = jsonString.split(",");
			Integer monitoring_interval = new Integer(document.get("monitoring_interval").toString());
			timer = new Timer();
			System.out.println("createTimerTask: "+docid);

			timer.scheduleAtFixedRate(new TimerTask() {
				@Override
				public void run() {
						//Put unique ID for the message for easier testing
						String uniqueMessageID = document.get("applicationName").toString() +"_"+ (new Date()).getTime();
						document.put("uniqueID", uniqueMessageID);
						//Within timer code,  Get the regions for this document, split
						for(int ir=0;ir<regions.length;ir++) {
							String regionString = regions[ir];
							regionString = regionString.replace("\"", "");
							System.out.println("TimerTask run: "+docid+" , region: "+regionString);
							String regionQueueName = regionString + "_" + queueSuffixString;
							
							try {
					        	//Within timertask, put message in different region queues
								sendMessageToRegionQueue(document.toString(), regionQueueName);
							} catch (IOException e) {
								e.printStackTrace();

							} catch (TimeoutException e) {
								e.printStackTrace();
							}
						}
						
						
				}
			}, 0, monitoring_interval.intValue() * 60 * 1000);
		
		return timer;
	}
	
	
	private void sendMessageToRegionQueue(String message,String regionQueueName) throws IOException, TimeoutException {
		ConnectionFactory factory = new ConnectionFactory();
	    Connection connection;

			factory.setHost("localhost");
			connection = factory.newConnection();
			Channel channel = connection.createChannel();
			
		    channel.queueDeclare(regionQueueName, true, false, false, null);

		    channel.basicPublish("", regionQueueName,
		        MessageProperties.BASIC, //Changed this to BASIC, it was PERSISTENT_BASIC
		        message.getBytes("UTF-8"));
		    System.out.println(" Sent message to "+ regionQueueName+": '" + message + "'");

		    channel.close();
		    connection.close();
	    
	}
  
}