package com.synmon.rest;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.GetResponse;
import com.rabbitmq.client.MessageProperties;
import com.synmon.common.CommonData;
import com.synmon.db.MongoDAO;

@Path("/getMessageFromQueue")
public class GetMessageFromQueueService {

	private String queueSuffixString = "CIEEM_task_queue";

	@GET
	@Path("/{regionName}")
	public Response getMsg(@PathParam("regionName") String regionName) {
		System.out.println("Region : " + regionName);
		int statusCode = 200;

		String regionQueueName = regionName + "_" + queueSuffixString;
		String output = "{'status':'Got message'}";
		JSONObject jsonmessage = new JSONObject();
		try {
			ConnectionFactory factory = new ConnectionFactory();
//			factory.setHost("localhost");
//		factory.setVirtualHost("/");
//		int port=5672;
//		factory.setPort(port);
//		factory.setUsername("zantmeter");
//		factory.setPassword("zantmeter2019");
//		amqp.connect('amqp://' + config.RabbitMQUserName + ':' + config.RabbitMQPassword + '@' + config.RabbitMQHost + ':5672

//			factory.setUri("amqp://zantmeter:zantmeter2019@ec2-13-126-49-100.ap-south-1.compute.amazonaws.com:5671/");
			 factory.setUsername("zantmeter");
			 factory.setPassword("zantmeter2019");
			 factory.setVirtualHost("/");
			 factory.setHost("localhost");
			 factory.setPort(5672);

			Connection connection = null;
			Channel channel = null;
			try {

				connection = factory.newConnection();

				channel = connection.createChannel();

				int count = channel.queueDeclare(regionQueueName, true, false, false, null).getMessageCount();

				System.out.println(" Reading messages from " + regionQueueName + ", count : " + count);

				boolean autoAck = false;
				GetResponse response = channel.basicGet(regionQueueName, autoAck);
				if (response == null) {
					// No message retrieved.
					// System.out.println("No messages received received");

					String msg = "No messages received for specified queue " + regionQueueName;
					output = "{'status':'" + msg + "'}";
				} else {
					AMQP.BasicProperties props = response.getProps();
					byte[] body = response.getBody();
					long deliveryTag = response.getEnvelope().getDeliveryTag();
					String message = new String(body, "UTF-8");
					// System.out.println(" Received '" + message + "'");
					channel.basicAck(deliveryTag, false); // acknowledge receipt of the message

					// Get Latest document
					JSONParser jsonparser = new JSONParser();
					JSONObject olddoc = (JSONObject) jsonparser.parse(message);
					JSONObject Objid = (JSONObject) jsonparser.parse(olddoc.get("_id").toString());
					String id = Objid.get("$oid").toString();
					// System.out.println(id);
					MongoDAO myDAO = new MongoDAO();
					String documentString = myDAO.getDocumentByID(id);

					JSONObject newdoc = (JSONObject) jsonparser.parse(documentString);
					olddoc.put("status", newdoc.get("status").toString());

					output = olddoc.toJSONString();
				}

				// System.out.println(channel.basicGet(regionQueueName,
				// false).getMessageCount());

			} catch (Exception ex) {
				System.out.println(ex);
				output = "{'status': 'ERROR:" + ex.getMessage() + "'}";
			} finally {
				if (channel != null) {
					try {
						channel.close();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (TimeoutException e) {
						e.printStackTrace();
					}

				}
				if (connection != null) {
					try {
						connection.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Response.status(statusCode).entity(output).build();

	}

}