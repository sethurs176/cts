package com.cts;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import io.netty.handler.timeout.TimeoutException;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.client.ClientUtil;

public class cognizantHomePage {
	private static TransactionWrapper myTransactionWrapper;
	private static String applicationName = "cognizanthomepage";
//	private static String serverURLPrefix="http://ec2-13-232-87-180.ap-south-1.compute.amazonaws.com:5000";
	private static String serverURLPrefix="http://ec2-13-232-1-36.ap-south-1.compute.amazonaws.com:5000";
	private static long standardThinkTime = 5000;// 5 secs
	private static String region;
	private static long sla=1000;

	public static void main(String[] args) throws InterruptedException, IOException, AWTException{
//		SeleniumScreenShot sc=new SeleniumScreenShot(applicationName, region);
		System.out.println("*************************************************************\t ");
//		String chromeDriverLocation = "C:\\chromedriver.exe";
		String chromeDriverLocation="C:\\SynMon\\Chromedriver\\chromedriver.exe";  
		//String userDataProfileLocation = "C:\\Users\\121009\\AppData\\Local\\Google\\Chrome\\User Data";
//		String chromeDriverLocation="C:\\SynMon\\chromedriver_win32\\chromedriver.exe";  
		String userDataProfileLocation = "C:\\Users\\Administrator\\AppData\\Local\\Google\\Chrome\\User Data";
		// Initialization code
		if(args!=null && args.length>0) {
			region = args[0];
		}else {
			region = "localhost";
		}
		System.setProperty("webdriver.chrome.driver", chromeDriverLocation);
		System.out.println("-------- STARTING MEASUREMENTS ---------- ");
		System.out.println("Region : " + region);
		System.out.println("Chrome Driver location : " + chromeDriverLocation);
		System.out.println("User data location : " + userDataProfileLocation);
		System.out.println("----------------------------------------- ");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		
		// get the Selenium proxy object
		//REQUIRED ONLY for Cognizant machines
		//InetSocketAddress myCognizantProxyAddress = new InetSocketAddress("proxy.cognizant.com", 6050);
		//myTransactionWrapper = new TransactionWrapper(applicationName, region, serverURLPrefix, myCognizantProxyAddress);
		myTransactionWrapper = new TransactionWrapper(applicationName, region, serverURLPrefix);
		

		BrowserMobProxy proxy = myTransactionWrapper.getProxy();
		Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
			try {
				String hostIp = Inet4Address.getLocalHost().getHostAddress();
				System.out.println("port : "+proxy.getPort());
				seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
				seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
			} catch (UnknownHostException e) {
				e.printStackTrace();
				System.exit(0);
			}
			
		ChromeOptions options = new ChromeOptions();
		//options.addArguments("headless");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		capabilities.setCapability(CapabilityType.SUPPORTS_APPLICATION_CACHE, true);
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		ChromeDriverService service = new ChromeDriverService.Builder().usingDriverExecutable(new File(chromeDriverLocation)).usingAnyFreePort().build();
		
		if(userDataProfileLocation!=null && !userDataProfileLocation.equals(""))
			options.addArguments("user-data-dir="+userDataProfileLocation);
		
		
		ChromeDriver driver=new ChromeDriver(service,capabilities);
		driver.manage().window().maximize();
		//Deleting all cookies first
				driver.manage().deleteAllCookies();
		WebDriverWait wait1 = new WebDriverWait(driver, 300);
		try{
			myTransactionWrapper.startTransactionEx("cognizanthomepage_t01_launch");
			driver.get("https://www.cognizant.com/");
			//driver.get("https://www.theverge.com/");
		    //wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"bodyId\"]/div[1]/div/div[4]/div[3]/div/div/ul/li[1]/a"))); //careers
		    //CXOptimizeCollector.EndTransaction("SC01_PersonalAuto_NewBusiness_T01_Launch", driver);
		    System.out.println("Navigating to cognizant home page");
		    myTransactionWrapper.endTransactionEx("cognizanthomepage_t01_launch", "PASS", sla, driver);
		}
		catch(TimeoutException e) {
			e.printStackTrace();
//			sc.screenShot(driver, "cognizanthomepage_t01_launch");
			myTransactionWrapper.endTransactionEx("cognizanthomepage_t01_launch", "FAIL-TransactionTimeout", sla, driver);
			e.printStackTrace();
			
		}
		catch(NoSuchElementException e) {
//			sc.screenShot(driver, "cognizanthomepage_t01_launch");
			myTransactionWrapper.endTransactionEx("cognizanthomepage_t01_launch", "FAIL-IncorrectResult", sla, driver);
			e.printStackTrace();
			
		}
		catch(Exception e) {
//			sc.screenShot(driver, "cognizanthomepage_t01_launch");
			myTransactionWrapper.endTransactionEx("cognizanthomepage_t01_launch", "FAIL", sla, driver);
			e.printStackTrace();
			
			
			
		}
		System.out.println("Before pause()");
		myTransactionWrapper.pause(standardThinkTime);
		System.out.println("after pause()");
		/*try{
			myTransactionWrapper.startTransactionEx("cognizanthomepage_t02_clickIndustries");
			driver.findElement(By.xpath("//*[@id=\"Industries\"]")).click();
		    wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"bodyId\"]/div[1]/div/div[4]/div[4]/div/div/div[2]/ul/li[1]/ul/li/div[2]/div[2]/h5"))); 
		    
		    System.out.println("click Industries");
		    
		    myTransactionWrapper.endTransactionEx("cognizanthomepage_t02_clickIndustries", "PASS", sla, driver);
		}
		catch(TimeoutException e) {
			e.printStackTrace();

			myTransactionWrapper.endTransactionEx("cognizanthomepage_t02_clickIndustries", "FAIL-TransactionTimeout", sla, driver);
			e.printStackTrace();
			
		}
		catch(NoSuchElementException e) {
//			sc.screenShot(driver, "cognizanthomepage_t01_launch");
			myTransactionWrapper.endTransactionEx("cognizanthomepage_t02_clickIndustries", "FAIL-IncorrectResult", sla, driver);
			e.printStackTrace();
			
			
			
		}
		catch(Exception e) {
			myTransactionWrapper.endTransactionEx("cognizanthomepage_t02_clickIndustries", "FAIL", sla, driver);
			e.printStackTrace();
			
			
			
		}
		myTransactionWrapper.pause(standardThinkTime);*/
System.out.println("Before close()");
		driver.close();
		System.out.println("Before quit()");
		driver.quit();
		System.out.println("Before System.exit()");
		System.exit(0);
		
	}
	 
}
//testing