package com.cts;

import java.io.File;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cts.TransactionWrapper;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.client.ClientUtil;

public class DisneyResortTest {
	private static TransactionWrapper myTransactionWrapper;
	private static String applicationName = "disneyresort";
	//private static String serverURLPrefix = "http://ec2-35-154-232-47.ap-south-1.compute.amazonaws.com:5000";
	private static String serverURLPrefix = "http://localhost:5000";
	// private static String dbServerHost =
	// "ec2-18-222-76-59.us-east-2.compute.amazonaws.com";

	// private static int dbServerPort = 9300;

	private static long standardThinkTime = 1000;// 1 secs
	private static String region;
	private static long sla = 3000;
	
	public static void main(String[] args) {
		System.out.println("*************************************************************\t ");
		String chromeDriverLocation = "C:\\SynMon\\Chromedriver\\chromedriver.exe";
		String userDataProfileLocation = "C:\\Users\\Administrator\\AppData\\Local\\Google\\Chrome\\User Data";
		// Initialization code

		if(args!=null && args.length>0) {
			region = args[0];
		}else {
			region = "localhost";
		}

		System.setProperty("webdriver.chrome.driver", chromeDriverLocation);
		System.out.println("-------- STARTING MEASUREMENTS ---------- ");
		System.out.println("Region : " + region);
		System.out.println("Chrome Driver location : " + chromeDriverLocation);
		System.out.println("User data location : " + userDataProfileLocation);
		System.out.println("----------------------------------------- ");
		myTransactionWrapper = new TransactionWrapper(applicationName, region, serverURLPrefix);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

		// get the Selenium proxy object
		BrowserMobProxy proxy = myTransactionWrapper.getProxy();
		Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
		try {
			String hostIp = Inet4Address.getLocalHost().getHostAddress();
			seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
			seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
			System.exit(0);
		}
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		capabilities.setCapability(CapabilityType.SUPPORTS_APPLICATION_CACHE, true);

		ChromeDriverService service = new ChromeDriverService.Builder()
				.usingDriverExecutable(new File(chromeDriverLocation)).usingAnyFreePort().build();
		ChromeOptions options = new ChromeOptions();
		/*
		 * if(userDataProfileLocation!=null && !userDataProfileLocation.equals(""))
		 * options.addArguments("user-data-dir="+userDataProfileLocation);
		 */

		ChromeDriver driver = new ChromeDriver(service, capabilities);
		driver.manage().window().maximize();
		//Deleting all cookies first
		driver.manage().deleteAllCookies();
		WebDriverWait wait = new WebDriverWait(driver, 300);

		//01_SelfCareHomePage
		try {
			myTransactionWrapper.startTransactionEx("01_LaunchDisneyResortPage");
			driver.get("https://disneyworld.disney.go.com/resorts/"); //Launches the page
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"detailPageLink-animal-kingdom-lodge\"]")));//text check on disney's animal kingdom lodge
		    myTransactionWrapper.endTransactionEx("01_LaunchDisneyResortPage", "PASS", sla, driver);
		}
		catch(TimeoutException e) {
			e.printStackTrace();
			myTransactionWrapper.endTransactionEx("01_LaunchDisneyResortPage", "FAIL-TransactionTimeout", sla, driver);
		}
		catch(NoSuchElementException e) {
			myTransactionWrapper.endTransactionEx("01_LaunchDisneyResortPage", "FAIL-IncorrectResult", sla, driver);
			e.printStackTrace();
		}
		catch(Exception e) {
			myTransactionWrapper.endTransactionEx("01_LaunchDisneyResortPage", "FAIL", sla, driver);
			e.printStackTrace();
		}
		
		
		myTransactionWrapper.pause(standardThinkTime);
		/*
		checkChatDialogDisplay(driver);
				
		//03_SelfCareProductDevices
		try {
			myTransactionWrapper.startTransactionEx("02_SelectAnimalKingdomLodge");
			driver.findElement(By.xpath("//*[@id=\"detailPageLink-animal-kingdom-lodge\"]")).click();//click disney's animal kingdom lodge
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"animalKingdomLodge\"]/div/div[1]/header/h1")));//text check on disney's animal kingdom lodge
		    myTransactionWrapper.endTransactionEx("02_SelectAnimalKingdomLodge", "PASS", sla, driver);
		}
		catch(TimeoutException e) {
			e.printStackTrace();
			myTransactionWrapper.endTransactionEx("02_SelectAnimalKingdomLodge", "FAIL-TransactionTimeout", sla, driver);
		}
		catch(NoSuchElementException e) {
			myTransactionWrapper.endTransactionEx("02_SelectAnimalKingdomLodge", "FAIL-IncorrectResult", sla, driver);
			e.printStackTrace();
		}
		catch(Exception e) {
			myTransactionWrapper.endTransactionEx("02_SelectAnimalKingdomLodge", "FAIL", sla, driver);
			e.printStackTrace();
		}
		
		myTransactionWrapper.pause(standardThinkTime);
		checkChatDialogDisplay(driver);
		
		
		//check if if chat now dialog is shown
		try {
			System.out.println("Checking if chatNow dialog is showing");
			boolean isChatDialogFound = driver.findElementByXPath("//*[@id=\"inviteReject\"]").isDisplayed();
			System.out.println("Check : " + isChatDialogFound + ", Clicking No");
			driver.findElement(By.xpath("//*[@id=\"inviteReject\"]/span/span")).click();
		}catch(Exception ex) {
			//do nothing
		}
		
		//Click CheckAvailability Dialog
		try {
			myTransactionWrapper.startTransactionEx("03_ClickCheckAvailabilityButton");
			driver.findElement(By.xpath("//*[@id=\"roomRatesForm\"]/div/span/span/span")).click();//click on Check Availability button 
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"modalTmpContent\"]/form/header/h2[1]")));//text check(Check Availability) for the window pop up
			System.out.println("text check(Check Availability) for the window pop up");
		    myTransactionWrapper.endTransactionEx("03_ClickCheckAvailabilityButton", "PASS", sla, driver);
		}
		catch(TimeoutException e) {
			e.printStackTrace();
			myTransactionWrapper.endTransactionEx("03_ClickCheckAvailabilityButton", "FAIL-TransactionTimeout", sla, driver);
		}
		catch(NoSuchElementException e) {
			myTransactionWrapper.endTransactionEx("03_ClickCheckAvailabilityButton", "FAIL-IncorrectResult", sla, driver);
			e.printStackTrace();
		}
		catch(Exception e) {
			myTransactionWrapper.endTransactionEx("03_ClickCheckAvailabilityButton", "FAIL", sla, driver);
			e.printStackTrace();
		}
		
		myTransactionWrapper.pause(standardThinkTime);
		
		//check if if chat now dialog is shown
		checkChatDialogDisplay(driver);
		
		//Entering data
		try {
			driver.findElementByXPath("//*[@name=\"checkInDate\"]").click();
			driver.findElementByXPath("//*[@id=\"ui-datepicker-div\"]/div/a[2]/span").click();//goes to march
			driver.findElementByXPath("//*[@id=\"ui-datepicker-div\"]/div/a[2]/span").click();
			driver.findElementByXPath("//*[@id=\"ui-datepicker-div\"]/div/a[2]/span").click();
			driver.findElementByXPath("//*[@id=\"ui-datepicker-div\"]/div/a[2]/span").click();
			driver.findElementByXPath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[3]/td[7]").click();
			driver.findElementByXPath("//*[@name=\"checkOutDate\"]").click();
			driver.findElementByXPath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[4]/td[2]").click();
		}catch(NoSuchElementException e) {
			e.printStackTrace();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		myTransactionWrapper.pause(standardThinkTime);
		
		checkChatDialogDisplay(driver);
		
		//05_SelfCareSupport
		try {
			myTransactionWrapper.startTransactionEx("04_ClickFindRoom");
			driver.findElement(By.xpath("//*[@name=\"findRoomButton\"]/span/span/span")).click();//click on Find a Room in that pop up window
			myTransactionWrapper.pause(2000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"animalKingdomLodge\"]/div/div[3]/div[4]/div/ul/li[1]/div/a")));//text check on animal kingdom lodge
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"launchWDW_Rooms_FloorplanImages_SavannaView\"]")));
			myTransactionWrapper.endTransactionEx("04_ClickFindRoom", "PASS", sla, driver);
			TakesScreenshot scrShot =((TakesScreenshot)driver);

	        //Call getScreenshotAs method to create image file
             //File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
	            //Move image file to new destination
               // File DestFile=new File("C:\\temp\\"+"04_ClickFindRoom_" + (new java.util.Date()).getTime());

	                //Copy file at destination
	             //   FileUtils.copyFile(SrcFile, DestFile);

			System.out.println("PASSED");
		}
		catch(TimeoutException e) {
			e.printStackTrace();
			myTransactionWrapper.endTransactionEx("04_ClickFindRoom", "FAIL-TransactionTimeout", sla, driver);
		}
		catch(NoSuchElementException e) {
			myTransactionWrapper.endTransactionEx("04_ClickFindRoom", "FAIL-IncorrectResult", sla, driver);
			e.printStackTrace();
		}
		catch(Exception e) {
			myTransactionWrapper.endTransactionEx("04_ClickFindRoom", "FAIL", sla, driver);
			e.printStackTrace();
		}

		myTransactionWrapper.pause(standardThinkTime);*/
		
		System.out.println("*************************************************************\t ");
		System.out.println("Before close()");
		driver.close();
		System.out.println("Before quit()");
		driver.quit();
		System.out.println("Completed");
		System.out.println("Before System.exit()");
		System.exit(0);
		

	}
	
	public static void checkChatDialogDisplay(ChromeDriver driver) {
		//check if if chat now dialog is shown
		try {
			System.out.println("Checking if chatNow dialog is showing");
			boolean isChatDialogFound = driver.findElementByXPath("//*[@id=\"inviteReject\"]").isDisplayed();
			System.out.println("Check : " + isChatDialogFound + ", Clicking No");
			driver.findElement(By.xpath("//*[@id=\"inviteReject\"]/span/span")).click();
		}catch(Exception ex) {
			//do nothing
		}
	}

}
